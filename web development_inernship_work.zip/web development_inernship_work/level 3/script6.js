function validateForm() {
    var fullName = document.getElementById('fullName').value.trim();
    var email = document.getElementById('email').value.trim();
    var phone = document.getElementById('phone').value.trim();
    var address = document.getElementById('address').value.trim();
    var course = document.getElementById('course').value;

    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    var phoneRegex = /^\d{10}$/;

    if (fullName === '' || email === '' || phone === '' || address === '' || course === '') {
        alert('All fields are required');
        return false;
    }

    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return false;
    }

    if (!phoneRegex.test(phone)) {
        alert('Please enter a 10-digit phone number');
        return false;
    }

    return true;
}
