document.addEventListener('DOMContentLoaded', () => {
  fetchData();
  document.getElementById('search-input').addEventListener('input', filterData);
});

async function fetchData() {
  const response = await fetch('https://jsonplaceholder.typicode.com/posts');
  const data = await response.json();
  displayData(data);
}

function displayData(data) {
  const container = document.getElementById('data-container');
  container.innerHTML = '';
  data.forEach(item => {
    const card = document.createElement('div');
    card.classList.add('card');
    card.innerHTML = `
      <h2>${item.title}</h2>
      <p>${item.body}</p>
    `;
    container.appendChild(card);
  });
}

function filterData() {
  const searchText = document.getElementById('search-input').value.toLowerCase();
  const cards = document.querySelectorAll('.card');
  cards.forEach(card => {
    const title = card.querySelector('h2').textContent.toLowerCase();
    const body = card.querySelector('p').textContent.toLowerCase();
    if (title.includes(searchText) || body.includes(searchText)) {
      card.style.display = 'block';
    } else {
      card.style.display = 'none';
    }
  });
}
